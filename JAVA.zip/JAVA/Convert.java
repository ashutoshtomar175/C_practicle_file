class Convert{
	public static void main(String ar[]){
		System.out.print("Input the Byte: ");
		byte a = 121;
		short x = (short)a;
		System.out.print("Short"+x+"\n");
		byte q = -121;
		int w = (int)q;
		System.out.print("Integer"+w);
		System.out.print("Input the int: ");
		int e = 12;
		short r = (short)e;
		System.out.print("\n"+"Short"+r)
		
	}
}