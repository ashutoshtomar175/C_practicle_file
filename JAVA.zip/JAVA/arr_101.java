class arr_101{
	public static void main(String[] ar){
		int a = Integer.parseInt(ar[0]);
		int b[] = new int[10];
		for(int i = 1;i<=a;i++){
			b[i] = Integer.parseInt(ar[0]);
		}
		for(int i = 1;i<=a;i++){
			System.out.print(b[i]);
		}

	}
}