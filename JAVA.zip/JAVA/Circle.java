import java.lang.Math;
class Circle{
	public static void main(String ar[]){
		int a = Integer.parseInt(ar[0]);
		double b = Math.pow(a,2);
		System.out.print((22/7)*b);
	}
}