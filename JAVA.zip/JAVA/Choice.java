import java.util.*;
class Choice{
	public static void main(String ar[]){
		Scanner v = new Scanner(System.in);
		String a = v.nexLine();
		switch (a){
			case "r":
				System.out.print("Red");
				break;
			case "y":
				System.out.print("yellow");
				break;
			default:
				System.out.print("Rede");
				

		}
	}
}