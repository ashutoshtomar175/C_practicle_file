class Pat
{
	public static void main(String ar[]){
		int a = Integer.parseInt(ar[0]);
		int i,j;
		for(i = 1 ; i<=a;i++){
			for(j = (a-i);j>=0;j--){
				System.out.print(" ");
			}
			// System.out.print("\n");
			for(j = i;j>=1;j--){
				System.out.print(j);
			}
			System.out.print("\n");

		}
	}
}