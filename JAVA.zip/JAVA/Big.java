import java.util.*;
class Big{
	public static void main(String[] arg){
		Scanner v = new Scanner(System.in);
		int a = v.nextInt();
		int b = v.nextInt();
		if(a>b){
			System.out.print("a is grater");
		}
		else{
			System.out.print("b is greater");
		}

	}
}