public class Xe {
    int paren(int a, int b){
        return (a+b);
    }
}
