class Command{
	public static void main(String ar[]){
		System.out.print(ar[0]);
	}
}