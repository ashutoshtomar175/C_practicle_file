class Phibo
{
	public static void main(String ar[]){
		int a = Integer.parseInt(ar[0]);
		int i,j = 0;
		for(i=1;i<=a;i++){
			j = j + i;
		}
		System.out.print(j);
	}
}