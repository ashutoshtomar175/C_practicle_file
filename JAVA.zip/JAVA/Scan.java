import java.util.*;
class Scan{
    public static void main(String[] arr){
        Scanner v = new Scanner(System.in);
        String a = v.nextLine();
        System.out.print(a);
    }
}