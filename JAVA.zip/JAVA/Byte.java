class Byte{
	public static void main(String args[]){
		byte a = 17;
		Byte b = new Byte(a);
		short c = b.shortValue();
		System.out.print(a+"="+c);
	}
}