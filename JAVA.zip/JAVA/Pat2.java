class Pat2
{
	public static void main(String ar[]){
		int a = Integer.parseInt(ar[0]);
		int i,j;
		for(i = 1 ; i<=a;i++){
			for(j = 1;j<=i;j++){
				System.out.print(" ");
			}
			for(j = (a-i);j>=1;j--){
				System.out.print(i);
			}
			
			System.out.print("\n");

		}
	}
}