import java.io.*;
class Shorting
{
	public static void main(String ar[]) throws Exception
	{
		BufferedReader a  = new BufferedReader(new InputStreamReader(System.in));
		int b = Integer.parseInt(a.readLine());
		int c[] = new int[b];
		for(int i=0;i<b;i++){
			c[i] = Integer.parseInt(a.readLine());
		}
		int d = b-1;
		int temp;
		boolean flag=false;
		for(int i=0;i<d;i++){
			for(int j=0;j<d-i;j++){
				if(c[j]>c[j+1]){
					temp = c[j];
					c[j] = c[j+1];
					c[j+1] = temp;
					flag = true;
				}
			}
		if(flag==false) break;
		else flag=false;
		}
		System.out.println("Yo Shorting done: ");
		for(int i=0;i<b;i++){
			System.out.println(c[i]);
		}
	}
}