
class Opt{
	public static void main(String ar[]){
		int a = Integer.parseInt(ar[0]);
		int b = Integer.parseInt(ar[1]);
		System.out.print("Added"+(a+b)+"\n");
		System.out.print("Multiple"+a*b+"\n");
		System.out.print("Divide"+(a/b)+"\n");
		System.out.print("Sub"+(a-b)+"\n");
	}
}