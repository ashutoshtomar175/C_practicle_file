class Swipe{
	public static void main(String ar[]){
		int a = Integer.parseInt(ar[0]);
		int b = Integer.parseInt(ar[1]);
		int c = a;
		a = b;
		b = c;
		System.out.print(a+"\n"+b);
	}
}