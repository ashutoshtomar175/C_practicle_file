class qw{
	public static void main(string ar[]){
		double a = 9.98;
		int q = a;
		System.out.print(q);
	}
}