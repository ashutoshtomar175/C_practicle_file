// class Prime{
// 	public static void main(String ar[]){
// 		int a  = Integer.parseInt(ar[0]);
// 		int i,r,count = 0;
// 		for(i = 2;i < a;i++){
// 			if(a%i==0){
// 				count = 1;
// 			}
// 		}
// 		if(count==0){
// 			System.out.print("prime");
// 		}
// 		else{
// 			System.out.print("not prime");

// 		}
// 	}
// }

class Prime{
    public static void main(String[] ar){
        int a  = Integer.parseInt(ar[0]);
        int i = 2,count = 0;
        while(i<a){
            if(a%i==0){
                count = 1;
            }
            i++;
        }
        if(count==0){
            System.out.print("prime");
        }
        else{
            System.out.print("not prime");

        }
    }
}