class sub
{
	int sub;
	void(int a){
		sub = a;
		int i,r = 1;
		for(i = 1;i <=a;i++){
			r = r*i;
		}
	}
}