class hello{
	public statc void main(String ar[]){
		System.out.print("Hello")
	}
}