import java.lang.Math;
import java.util.*;
public class import_math {
    public static void main(String ar[]){
        Scanner v = new Scanner(System.in);
        double a = v.nextDouble();
        double y = Math.sqrt(a);
        System.out.print(y);
    }
}
