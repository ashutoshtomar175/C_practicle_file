class tringle{
    public static void main(String ar[]){
        float w;
        area tri = new area();
        tri.hel(23,43);
        w = tri.length + tri.bredth;
        System.out.print(w);
    }
}