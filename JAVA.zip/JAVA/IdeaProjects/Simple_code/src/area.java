class area{
    float length;
    float bredth;
    void hel(float a, float b){
        length = a;
        bredth = b;
    }
}
class room{
    public static void main(String ar[]){
        float y;
        area are = new area();
        are.hel(12,12);
        y = are.length * are.bredth;
        System.out.print(y);
    }
}