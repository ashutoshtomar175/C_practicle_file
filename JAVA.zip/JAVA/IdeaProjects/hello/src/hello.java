import java.util.*;
class Pattern{
    public static void main(String args[]){
        Scanner v = new Scanner(System.in);
        int q = v.nextInt();
//        System.out.print(q);
        for(int i = 0;i<q;i++){
            for(int j = i;j<q;j++){
                System.out.printf("*");
            }
            System.out.printf("\n");
        }
    }
}