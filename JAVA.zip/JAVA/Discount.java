import java.util.*;
class Discount{
		public static void main(String ar[]){
		Scanner v = new Scanner(System.in);
		double a = v.nextDouble();
		if(a>=20000){
			double b = a/(10*100);
			double c = (a - b);
			System.out.print(c);
		}
		else{
			System.out.print("nope");
		}
	}2
}