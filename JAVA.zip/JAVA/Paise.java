import java.util.*;
class Paise{
	public static void main(String ar[]){
		int i,r = 1;
		System.out.print("Enter the money to convert into paise: ");
		Scanner v = new Scanner(System.in);
		double a = v.nextDouble();
		int b = (int) a;
		float c = (float) (a - b);
		String g = String.valueOf(c);
		int d = g.length();
		int e = d - 1;
		for(i=1;i<=e;i++){
			r = r*10;
		}
		double f = a*r;
		int h = (int) f;
		System.out.print("paise:  " + h);
	}
}

