import java.util.*;
class Swi2{
    public static void main(String[] args){
        Scanner v = new Scanner(System.in);
        String q = v.nextLine();
        switch(q){
            case"m" -> System.out.print("Monday");
            case"t" -> System.out.print("Tuseday");
            case"w" -> System.out.print("Wednessday");
            case "th" -> System.out.print("thursday");
            default -> System.out.print("qw");
        }
    }
}