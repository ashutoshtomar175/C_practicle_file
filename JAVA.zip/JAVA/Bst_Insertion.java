public class Bst_Insertion{
    static class Node{
        int data;
        Node left;
        Node right;
        Node(int data){
            this.data= data;
        }
    }
//        Algorithm of Binary Search Tree Insertion
    public static Node bst(Node root, int data){
        if(root == null){
            root = new Node(data);
            return root;
        }
        if(root.data>data){
            root.left = bst(root.left, data);
        }
        else{
            root.right = bst(root.right, data);
        }
        return root;

    }
    public static void Inorder(Node root){
        if(root ==null){
            return;
        }
        Inorder(root.left);
        System.out.println(root.data);
        Inorder(root.right);
    }

    public static void main(String[] args){
        int[] arr = {-13,2,3,4,5,6};
        Node root = null;
        for(int i=0;i<arr.length; i++){
            root = bst(root, arr[i]);
        }
        Inorder(root);
    }

}