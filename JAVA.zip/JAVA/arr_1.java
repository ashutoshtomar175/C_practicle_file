import java.io.*;
import java.io.InputStreamReader;
class arr_1
{
	public static void main(String[] ar) throws Exception
	{
		int r = 0,l;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Ente rthe num: ");
		int b = Integer.parseInt(br.readLine());
		int[] c = new int[b];
		for(int i=0;i<b;i++){
			c[i] = Integer.parseInt(br.readLine());
		}
		for(int i=0;i<b;i++){
			r = r+c[i];
		}
		l = r/2;
		System.out.println(r);
		System.out.println(l);

	}
}