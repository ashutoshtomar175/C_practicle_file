class Hello{
	public static void main(String ar[]){
		System.out.print("heelo");
	}
}